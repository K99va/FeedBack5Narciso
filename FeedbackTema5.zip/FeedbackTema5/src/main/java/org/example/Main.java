// Implementación de Patrones de Diseño en Java

// 1. Patrón Creacional: Factory Method
// Permite la creación de objetos sin especificar la clase exacta.
import java.util.ArrayList;
import java.util.List;


interface Producto {
    void usar();
}

class ProductoConcretoA implements Producto {
    public void usar() {
        System.out.println("Usando Producto A");
    }
}

class ProductoConcretoB implements Producto {
    public void usar() {
        System.out.println("Usando Producto B");
    }
}

abstract class Creador {
    abstract Producto crearProducto();
}

class CreadorConcretoA extends Creador {
    Producto crearProducto() {
        return new ProductoConcretoA();
    }
}

class CreadorConcretoB extends Creador {
    Producto crearProducto() {
        return new ProductoConcretoB();
    }
}

// 2. Patrón Estructural: Adapter
// Permite la compatibilidad entre interfaces diferentes.

interface EnchufeEuropeo {
    void conectar();
}

class EnchufeEspañol implements EnchufeEuropeo {
    public void conectar() {
        System.out.println("Conectado a enchufe europeo");
    }
}

interface EnchufeAmericano {
    void plugIn();
}

class Adaptador implements EnchufeAmericano {
    private EnchufeEuropeo enchufe;

    public Adaptador(EnchufeEuropeo enchufe) {
        this.enchufe = enchufe;
    }

    public void plugIn() {
        enchufe.conectar();
        System.out.println("Adaptador convierte la conexión");
    }
}

// 3. Patrón de Comportamiento: Observer
// Define una relación de suscriptor entre objetos para notificar cambios.



interface Observador {
    void actualizar(String mensaje);
}

class Usuario implements Observador {
    private String nombre;

    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    public void actualizar(String mensaje) {
        System.out.println(nombre + " ha recibido el mensaje: " + mensaje);
    }
}

class Canal {
    private List<Observador> suscriptores = new ArrayList<>();

    public void suscribir(Observador o) {
        suscriptores.add(o);
    }

    public void notificar(String mensaje) {
        for (Observador o : suscriptores) {
            o.actualizar(mensaje);
        }
    }
}

// Ejemplo de uso
public class Main {
    public static void main(String[] args) {
        // Factory Method
        Creador creador = new CreadorConcretoA();
        Producto producto = creador.crearProducto();
        producto.usar();

        // Adapter
        EnchufeEuropeo enchufe = new EnchufeEspañol();
        EnchufeAmericano adaptador = new Adaptador(enchufe);
        adaptador.plugIn();

        // Observer
        Canal canal = new Canal();
        Usuario usuario1 = new Usuario("Juan");
        Usuario usuario2 = new Usuario("Ana");
        canal.suscribir(usuario1);
        canal.suscribir(usuario2);
        canal.notificar("Nuevo video disponible");
    }
}
